INSERT INTO users (email, password_hash, name, monthly_income, currency, is_profile_completed)
VALUES ('demo@tenten.app', 'local-demo', '텐텐 사용자', 2500000, 'KRW', 1);

INSERT INTO categories (user_id, name, type, is_default) VALUES
(1, '급여', 'income', 1),
(1, '용돈', 'income', 1),
(1, '식비', 'expense', 1),
(1, '교통', 'expense', 1),
(1, '쇼핑', 'expense', 1);

INSERT INTO budgets (user_id, month, total_limit, note)
VALUES (1, '2026-04', 1200000, '4월 예산');

INSERT INTO budget_categories (user_id, month, category_id, limit_amount, spent_amount) VALUES
(1, '2026-04', 3, 500000, 120000),
(1, '2026-04', 4, 200000, 55000),
(1, '2026-04', 5, 300000, 98000);

INSERT INTO fixed_expenses (user_id, category_id, title, amount, cycle, billing_day, next_due_date, is_active)
VALUES (1, 4, '정기 교통권', 60000, 'monthly', 1, '2026-05-01', 1);

INSERT INTO transactions (user_id, category_id, type, amount, occurred_at, title, memo) VALUES
(1, 1, 'income', 2500000, '2026-04-01T09:00:00', '급여', '4월 급여'),
(1, 3, 'expense', 12000, '2026-04-02T12:30:00', '식비', '점심'),
(1, 4, 'expense', 1500, '2026-04-02T18:00:00', '교통', '버스');

INSERT INTO notification_settings (user_id, master_enabled, daily_summary_enabled, daily_summary_time)
VALUES (1, 1, 1, '21:00');

INSERT INTO notification_rules (user_id, fixed_expense_id, title, is_enabled, remind_days_before, remind_at)
VALUES (1, 1, '정기 교통권 결제 알림', 1, 1, '09:00');
