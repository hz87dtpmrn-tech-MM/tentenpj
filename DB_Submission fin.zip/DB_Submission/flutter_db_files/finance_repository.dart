import 'package:integrated_expense/data/database/app_database.dart';
import 'package:sqflite/sqflite.dart';

class FinanceRepository {
  Future<Database> get _db async => AppDatabase.instance.database;

  Future<int> ensureDefaultUser() async {
    final db = await _db;
    final existing = await db.query(
      'users',
      columns: ['id'],
      orderBy: 'id ASC',
      limit: 1,
    );

    if (existing.isNotEmpty) {
      return existing.first['id'] as int;
    }

    final userId = await db.insert('users', {
      'email': 'demo@tenten.app',
      'password_hash': 'local-demo',
      'name': '텐텐 사용자',
      'monthly_income': 2500000,
      'currency': 'KRW',
      'is_profile_completed': 1,
    });

    await _seedDefaultCategories(db, userId);
    await db.insert('notification_settings', {'user_id': userId});

    return userId;
  }

  Future<void> _seedDefaultCategories(Database db, int userId) async {
    const expenseCategories = ['식비', '교통', '쇼핑', '공과금', '의료', '문화여가', '기타'];
    const incomeCategories = ['급여', '용돈', '부수입', '기타'];

    for (final name in expenseCategories) {
      await db.insert(
        'categories',
        {
          'user_id': userId,
          'name': name,
          'type': 'expense',
          'is_default': 1,
        },
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }

    for (final name in incomeCategories) {
      await db.insert(
        'categories',
        {
          'user_id': userId,
          'name': name,
          'type': 'income',
          'is_default': 1,
        },
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
  }

  Future<int?> _findCategoryId(int userId, String type, String categoryName) async {
    final db = await _db;
    final rows = await db.query(
      'categories',
      columns: ['id'],
      where: 'user_id = ? AND type = ? AND name = ?',
      whereArgs: [userId, type, categoryName],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return rows.first['id'] as int;
  }

  Future<void> addTransaction({
    required int userId,
    required String type,
    required int amount,
    required String categoryName,
    String? memo,
  }) async {
    final db = await _db;
    final categoryId = await _findCategoryId(userId, type, categoryName);

    await db.insert('transactions', {
      'user_id': userId,
      'category_id': categoryId,
      'type': type,
      'amount': amount,
      'occurred_at': DateTime.now().toIso8601String(),
      'title': categoryName,
      'memo': (memo != null && memo.trim().isNotEmpty) ? memo.trim() : null,
    });
  }
}
