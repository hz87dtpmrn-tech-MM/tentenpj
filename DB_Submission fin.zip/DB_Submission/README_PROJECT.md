주요 기능

월별 수입/지출/잔액 요약
거래내역 등록, 조회, 필터, 삭제
카테고리별 지출 리포트
알림 설정(전체 알림, 일일 요약, 개별 규칙)

DB 스키마 구성
users
categories
fixed_expenses
transactions
budgets
budget_categories
notification_settings
notification_rules

폴더 구성

schema.sql: 최종 SQLite 스키마
sample_data.sql: 테스트용 샘플 데이터
db_apply_guide.md: 적용/실행 가이드
flutter_db_files/: DB 연동 기본 코드
DB_UX_Code/: UX 동작 포함 코드(홈/내역/리포트/알림)

실행 방법

SQLite 스키마 실행

bash
cd /Users/mogwamogwa/Downloads/tenten_pj/tenten/DB_Submission
sqlite3 app.db ".read schema.sql"
sqlite3 app.db ".read sample_data.sql"

Flutter 앱 반영

아래 파일을 Flutter 프로젝트 `lib`에 복사:

flutter_db_files/app_database.dart -> lib/data/database/app_database.dart
flutter_db_files/finance_repository.dart
lib/data/repositories/finance_repository.dart
DB_UX_Code/home_screen.dart-> lib/screens/home/home_screen.dart
