import 'package:integrated_expense/data/database/app_database.dart';
import 'package:sqflite/sqflite.dart';

class FinanceRepository {
  Future<Database> get _db async => AppDatabase.instance.database;

  Future<int> ensureDefaultUser() async {
    final db = await _db;
    final existing = await db.query(
      'users',
      columns: ['id'],
      orderBy: 'id ASC',
      limit: 1,
    );

    if (existing.isNotEmpty) {
      return existing.first['id'] as int;
    }

    final userId = await db.insert('users', {
      'email': 'demo@tenten.app',
      'password_hash': 'local-demo',
      'name': '텐텐 사용자',
      'monthly_income': 2500000,
      'currency': 'KRW',
      'is_profile_completed': 1,
    });

    await _seedDefaultCategories(db, userId);
    await db.insert('notification_settings', {'user_id': userId});

    return userId;
  }

  Future<void> _seedDefaultCategories(Database db, int userId) async {
    const expenseCategories = ['식비', '교통', '쇼핑', '공과금', '의료', '문화여가', '기타'];
    const incomeCategories = ['급여', '용돈', '부수입', '기타'];

    for (final name in expenseCategories) {
      await db.insert(
        'categories',
        {
          'user_id': userId,
          'name': name,
          'type': 'expense',
          'is_default': 1,
        },
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }

    for (final name in incomeCategories) {
      await db.insert(
        'categories',
        {
          'user_id': userId,
          'name': name,
          'type': 'income',
          'is_default': 1,
        },
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
  }

  Future<int?> _findCategoryId(int userId, String type, String categoryName) async {
    final db = await _db;
    final rows = await db.query(
      'categories',
      columns: ['id'],
      where: 'user_id = ? AND type = ? AND name = ?',
      whereArgs: [userId, type, categoryName],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return rows.first['id'] as int;
  }

  Future<void> addTransaction({
    required int userId,
    required String type,
    required int amount,
    required String categoryName,
    String? memo,
  }) async {
    final db = await _db;
    final categoryId = await _findCategoryId(userId, type, categoryName);

    await db.insert('transactions', {
      'user_id': userId,
      'category_id': categoryId,
      'type': type,
      'amount': amount,
      'occurred_at': DateTime.now().toIso8601String(),
      'title': categoryName,
      'memo': (memo != null && memo.trim().isNotEmpty) ? memo.trim() : null,
    });
  }

  Future<Map<String, int>> getMonthlySummary({
    required int userId,
    required String month,
  }) async {
    final db = await _db;
    final rows = await db.rawQuery(
      '''
      SELECT
        COALESCE(SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END), 0) AS income_total,
        COALESCE(SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END), 0) AS expense_total
      FROM transactions
      WHERE user_id = ? AND substr(occurred_at, 1, 7) = ?
      ''',
      [userId, month],
    );

    final row = rows.first;
    final income = (row['income_total'] as int?) ?? 0;
    final expense = (row['expense_total'] as int?) ?? 0;
    return {
      'income': income,
      'expense': expense,
      'balance': income - expense,
    };
  }

  Future<List<Map<String, dynamic>>> getExpenseByCategory({
    required int userId,
    required String month,
  }) async {
    final db = await _db;
    return db.rawQuery(
      '''
      SELECT
        COALESCE(c.name, t.title, '기타') AS category_name,
        SUM(t.amount) AS amount
      FROM transactions t
      LEFT JOIN categories c ON c.id = t.category_id
      WHERE t.user_id = ? AND t.type = 'expense' AND substr(t.occurred_at, 1, 7) = ?
      GROUP BY COALESCE(c.name, t.title, '기타')
      ORDER BY amount DESC
      ''',
      [userId, month],
    );
  }

  Future<List<Map<String, dynamic>>> getTransactions({
    required int userId,
    String? type,
    String? month,
  }) async {
    final db = await _db;
    final where = <String>['t.user_id = ?'];
    final args = <Object?>[userId];
    if (type != null) {
      where.add('t.type = ?');
      args.add(type);
    }
    if (month != null) {
      where.add("substr(t.occurred_at, 1, 7) = ?");
      args.add(month);
    }

    return db.rawQuery(
      '''
      SELECT
        t.id,
        t.type,
        t.amount,
        t.occurred_at,
        t.title,
        t.memo,
        COALESCE(c.name, t.title, '기타') AS category_name
      FROM transactions t
      LEFT JOIN categories c ON c.id = t.category_id
      WHERE ${where.join(' AND ')}
      ORDER BY t.occurred_at DESC
      ''',
      args,
    );
  }

  Future<void> deleteTransaction(int id) async {
    final db = await _db;
    await db.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }

  Future<Map<String, dynamic>> getNotificationSettings(int userId) async {
    final db = await _db;
    final rows = await db.query(
      'notification_settings',
      where: 'user_id = ?',
      whereArgs: [userId],
      limit: 1,
    );
    if (rows.isNotEmpty) return rows.first;

    final id = await db.insert(
      'notification_settings',
      {'user_id': userId},
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
    final createdRows = await db.query(
      'notification_settings',
      where: id > 0 ? 'id = ?' : 'user_id = ?',
      whereArgs: id > 0 ? [id] : [userId],
      limit: 1,
    );
    return createdRows.first;
  }

  Future<void> updateNotificationSettings({
    required int userId,
    required bool masterEnabled,
    required bool dailySummaryEnabled,
  }) async {
    final db = await _db;
    await db.update(
      'notification_settings',
      {
        'master_enabled': masterEnabled ? 1 : 0,
        'daily_summary_enabled': dailySummaryEnabled ? 1 : 0,
      },
      where: 'user_id = ?',
      whereArgs: [userId],
    );
  }

  Future<List<Map<String, dynamic>>> getNotificationRules(int userId) async {
    final db = await _db;
    return db.query(
      'notification_rules',
      where: 'user_id = ?',
      whereArgs: [userId],
      orderBy: 'id DESC',
    );
  }

  Future<void> addNotificationRule({
    required int userId,
    required String title,
  }) async {
    final db = await _db;
    await db.insert('notification_rules', {
      'user_id': userId,
      'title': title,
      'is_enabled': 1,
      'remind_days_before': 1,
      'remind_at': '09:00',
    });
  }

  Future<void> updateNotificationRuleEnabled({
    required int id,
    required bool enabled,
  }) async {
    final db = await _db;
    await db.update(
      'notification_rules',
      {'is_enabled': enabled ? 1 : 0},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> deleteNotificationRule(int id) async {
    final db = await _db;
    await db.delete('notification_rules', where: 'id = ?', whereArgs: [id]);
  }
}
