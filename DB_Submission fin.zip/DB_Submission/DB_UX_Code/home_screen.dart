import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:integrated_expense/data/repositories/finance_repository.dart';

class AppTheme {
  static const Color primary = Color(0xFF3B6FF0);
  static const Color background = Color(0xFFF5F6FA);
  static const Color cardBg = Colors.white;
  static const Color textPrimary = Color(0xFF1A1D2E);
  static const Color textSecondary = Color(0xFF8A8FA8);
  static const Color income = Color(0xFF3B6FF0);
  static const Color expense = Color(0xFFFF6B6B);
  static const Color divider = Color(0xFFEEEFF5);
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;
  int _refreshTick = 0;

  @override
  Widget build(BuildContext context) {
    final screens = [
      HomeScreen(refreshTick: _refreshTick),
      HistoryScreen(refreshTick: _refreshTick),
      ReportScreen(refreshTick: _refreshTick),
      const NotificationScreen(),
      const MyPagePlaceholder(),
    ];

    return Scaffold(
      body: screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (i) => setState(() => _currentIndex = i),
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.white,
        selectedItemColor: AppTheme.primary,
        unselectedItemColor: AppTheme.textSecondary,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: '홈'),
          BottomNavigationBarItem(icon: Icon(Icons.receipt_long_rounded), label: '내역'),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart_rounded), label: '리포트'),
          BottomNavigationBarItem(icon: Icon(Icons.notifications_rounded), label: '알림'),
          BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: '마이'),
        ],
      ),
      floatingActionButton: _currentIndex == 0
          ? FloatingActionButton(
              onPressed: () => _showAddTransactionSheet(context),
              backgroundColor: AppTheme.primary,
              child: const Icon(Icons.add),
            )
          : null,
    );
  }

  void _showAddTransactionSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => AddTransactionSheet(
        onSaved: () => setState(() => _refreshTick++),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.refreshTick});

  final int refreshTick;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_HomeData>(
      key: ValueKey(refreshTick),
      future: _load(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final data = snapshot.data!;
        final monthLabel = DateFormat('yyyy년 M월').format(DateTime.now());
        return SafeArea(
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(child: _header(monthLabel)),
              SliverToBoxAdapter(child: _summaryCard(data.summary)),
              SliverToBoxAdapter(child: _categoryList(data.categories)),
              const SliverToBoxAdapter(child: SizedBox(height: 80)),
            ],
          ),
        );
      },
    );
  }

  Future<_HomeData> _load() async {
    final repo = FinanceRepository();
    final userId = await repo.ensureDefaultUser();
    final month = DateFormat('yyyy-MM').format(DateTime.now());
    final summary = await repo.getMonthlySummary(userId: userId, month: month);
    final categories = await repo.getExpenseByCategory(userId: userId, month: month);
    return _HomeData(summary: summary, categories: categories);
  }

  Widget _header(String monthLabel) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('내 지출관리', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
              Text(monthLabel, style: const TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
            ],
          ),
          const Icon(Icons.notifications_outlined),
        ],
      ),
    );
  }

  Widget _summaryCard(Map<String, int> summary) {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.primary,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('이번 달 잔액', style: TextStyle(color: Colors.white70, fontSize: 13)),
          const SizedBox(height: 6),
          Text(
            '${summary['balance']! >= 0 ? '+' : ''}${_won(summary['balance']!)}원',
            style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: Text('수입 ${_won(summary['income']!)}원', style: const TextStyle(color: Colors.white))),
              Expanded(child: Text('지출 ${_won(summary['expense']!)}원', style: const TextStyle(color: Colors.white))),
            ],
          ),
        ],
      ),
    );
  }

  Widget _categoryList(List<Map<String, dynamic>> categories) {
    final total = categories.fold<int>(0, (sum, e) => sum + ((e['amount'] as int?) ?? 0));
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('카테고리별 지출', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
            child: categories.isEmpty
                ? const Padding(
                    padding: EdgeInsets.all(20),
                    child: Text('이번 달 지출 내역이 없습니다.', style: TextStyle(color: AppTheme.textSecondary)),
                  )
                : ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: categories.length,
                    separatorBuilder: (_, __) => const Divider(height: 1, color: AppTheme.divider),
                    itemBuilder: (_, i) {
                      final row = categories[i];
                      final amount = (row['amount'] as int?) ?? 0;
                      final ratio = total == 0 ? 0.0 : amount / total;
                      return ListTile(
                        title: Text('${row['category_name']}'),
                        subtitle: LinearProgressIndicator(value: ratio, color: AppTheme.expense, backgroundColor: AppTheme.divider),
                        trailing: Text('-${_won(amount)}원', style: const TextStyle(fontWeight: FontWeight.w700)),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key, required this.refreshTick});
  final int refreshTick;

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final _repo = FinanceRepository();
  String _filter = 'all';

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      key: ValueKey('${widget.refreshTick}-$_filter'),
      future: _load(),
      builder: (context, snapshot) {
        final rows = snapshot.data ?? [];
        return Scaffold(
          appBar: AppBar(title: const Text('전체 내역')),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'all', label: Text('전체')),
                    ButtonSegment(value: 'income', label: Text('수입')),
                    ButtonSegment(value: 'expense', label: Text('지출')),
                  ],
                  selected: {_filter},
                  onSelectionChanged: (s) => setState(() => _filter = s.first),
                ),
              ),
              Expanded(
                child: rows.isEmpty
                    ? const Center(child: Text('내역이 없습니다.'))
                    : ListView.builder(
                        itemCount: rows.length,
                        itemBuilder: (_, i) {
                          final r = rows[i];
                          return ListTile(
                            title: Text('${r['category_name']}'),
                            subtitle: Text('${r['occurred_at']}'.replaceFirst('T', ' ').substring(0, 16)),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  '${r['type'] == 'income' ? '+' : '-'}${_won(r['amount'] as int)}원',
                                  style: TextStyle(
                                    color: r['type'] == 'income' ? AppTheme.income : AppTheme.expense,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete_outline),
                                  onPressed: () async {
                                    await _repo.deleteTransaction(r['id'] as int);
                                    if (mounted) setState(() {});
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final userId = await _repo.ensureDefaultUser();
    return _repo.getTransactions(
      userId: userId,
      type: _filter == 'all' ? null : _filter,
      month: DateFormat('yyyy-MM').format(DateTime.now()),
    );
  }
}

class ReportScreen extends StatelessWidget {
  const ReportScreen({super.key, required this.refreshTick});
  final int refreshTick;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_HomeData>(
      key: ValueKey(refreshTick),
      future: _load(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final categories = snapshot.data!.categories.take(5).toList();
        return Scaffold(
          appBar: AppBar(title: const Text('월간 리포트')),
          body: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('카테고리 지출 TOP5', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                const SizedBox(height: 12),
                SizedBox(
                  height: 220,
                  child: BarChart(
                    BarChartData(
                      gridData: const FlGridData(show: false),
                      borderData: FlBorderData(show: false),
                      titlesData: FlTitlesData(
                        leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            getTitlesWidget: (value, meta) {
                              final i = value.toInt();
                              if (i < 0 || i >= categories.length) return const SizedBox.shrink();
                              return Text('${categories[i]['category_name']}', style: const TextStyle(fontSize: 10));
                            },
                          ),
                        ),
                      ),
                      barGroups: List.generate(categories.length, (i) {
                        final y = ((categories[i]['amount'] as int?) ?? 0).toDouble();
                        return BarChartGroupData(x: i, barRods: [BarChartRodData(toY: y, color: AppTheme.primary)]);
                      }),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<_HomeData> _load() async {
    final repo = FinanceRepository();
    final userId = await repo.ensureDefaultUser();
    final month = DateFormat('yyyy-MM').format(DateTime.now());
    final summary = await repo.getMonthlySummary(userId: userId, month: month);
    final categories = await repo.getExpenseByCategory(userId: userId, month: month);
    return _HomeData(summary: summary, categories: categories);
  }
}

class AddTransactionSheet extends StatefulWidget {
  const AddTransactionSheet({super.key, required this.onSaved});
  final VoidCallback onSaved;

  @override
  State<AddTransactionSheet> createState() => _AddTransactionSheetState();
}

class _AddTransactionSheetState extends State<AddTransactionSheet> {
  final _repo = FinanceRepository();
  bool _isExpense = true;
  final _amountController = TextEditingController();
  final _memoController = TextEditingController();
  String _selectedCategory = '식비';

  final _expenseCategories = ['식비', '교통', '쇼핑', '공과금', '의료', '문화여가', '기타'];
  final _incomeCategories = ['급여', '용돈', '부수입', '기타'];

  @override
  void dispose() {
    _amountController.dispose();
    _memoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final categories = _isExpense ? _expenseCategories : _incomeCategories;
    return Container(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [_toggle('지출', true), const SizedBox(width: 8), _toggle('수입', false)]),
            const SizedBox(height: 16),
            TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(hintText: '금액 입력', suffixText: '원'),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: categories
                  .map((cat) => ChoiceChip(
                        label: Text(cat),
                        selected: _selectedCategory == cat,
                        onSelected: (_) => setState(() => _selectedCategory = cat),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 12),
            TextField(controller: _memoController, decoration: const InputDecoration(hintText: '메모(선택)')),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(onPressed: _save, child: const Text('등록하기')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _toggle(String label, bool isExpense) {
    return ChoiceChip(
      label: Text(label),
      selected: _isExpense == isExpense,
      onSelected: (_) {
        setState(() {
          _isExpense = isExpense;
          _selectedCategory = isExpense ? '식비' : '급여';
        });
      },
    );
  }

  Future<void> _save() async {
    final amount = int.tryParse(_amountController.text.trim());
    if (amount == null || amount <= 0) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('금액을 올바르게 입력해주세요.')));
      return;
    }

    final userId = await _repo.ensureDefaultUser();
    await _repo.addTransaction(
      userId: userId,
      type: _isExpense ? 'expense' : 'income',
      amount: amount,
      categoryName: _selectedCategory,
      memo: _memoController.text,
    );
    if (!mounted) return;
    widget.onSaved();
    Navigator.pop(context);
  }
}

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  final _repo = FinanceRepository();
  bool _loading = true;
  int _userId = 0;
  bool _masterEnabled = true;
  bool _dailySummaryEnabled = true;
  List<Map<String, dynamic>> _rules = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final userId = await _repo.ensureDefaultUser();
    final settings = await _repo.getNotificationSettings(userId);
    final rules = await _repo.getNotificationRules(userId);
    if (!mounted) return;
    setState(() {
      _userId = userId;
      _masterEnabled = (settings['master_enabled'] as int? ?? 1) == 1;
      _dailySummaryEnabled = (settings['daily_summary_enabled'] as int? ?? 1) == 1;
      _rules = rules;
      _loading = false;
    });
  }

  Future<void> _saveSettings() async {
    await _repo.updateNotificationSettings(
      userId: _userId,
      masterEnabled: _masterEnabled,
      dailySummaryEnabled: _dailySummaryEnabled,
    );
  }

  Future<void> _addRule() async {
    final controller = TextEditingController();
    final title = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('알림 항목 추가'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: '예: 카드값'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('취소')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('추가'),
          ),
        ],
      ),
    );
    if (title == null || title.isEmpty) return;
    await _repo.addNotificationRule(userId: _userId, title: title);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    return Scaffold(
      appBar: AppBar(title: const Text('알림 관리')),
      floatingActionButton: FloatingActionButton(
        onPressed: _addRule,
        child: const Icon(Icons.add),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SwitchListTile(
            value: _masterEnabled,
            onChanged: (v) async {
              setState(() => _masterEnabled = v);
              await _saveSettings();
            },
            title: const Text('알림 전체 ON/OFF'),
          ),
          SwitchListTile(
            value: _dailySummaryEnabled,
            onChanged: (v) async {
              setState(() => _dailySummaryEnabled = v);
              await _saveSettings();
            },
            title: const Text('일일 요약 알림'),
          ),
          const SizedBox(height: 12),
          const Text('개별 알림 항목', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          if (_rules.isEmpty)
            const ListTile(
              title: Text('등록된 알림 항목이 없습니다.'),
              subtitle: Text('우측 하단 + 버튼으로 추가하세요.'),
            )
          else
            ..._rules.map((rule) {
              final enabled = (rule['is_enabled'] as int? ?? 1) == 1;
              return ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text('${rule['title']}'),
                subtitle: Text('${rule['remind_days_before']}일 전 · ${rule['remind_at']}'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Switch(
                      value: enabled,
                      onChanged: (v) async {
                        await _repo.updateNotificationRuleEnabled(
                          id: rule['id'] as int,
                          enabled: v,
                        );
                        await _load();
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        await _repo.deleteNotificationRule(rule['id'] as int);
                        await _load();
                      },
                    ),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }
}

class MyPagePlaceholder extends StatelessWidget {
  const MyPagePlaceholder({super.key});
  @override
  Widget build(BuildContext context) => const _PlaceholderScreen(title: '마이페이지');
}

class _PlaceholderScreen extends StatelessWidget {
  const _PlaceholderScreen({required this.title});
  final String title;
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: Center(child: Text('$title 화면\n(준비 중)', textAlign: TextAlign.center)),
      );
}

class _HomeData {
  const _HomeData({required this.summary, required this.categories});
  final Map<String, int> summary;
  final List<Map<String, dynamic>> categories;
}

String _won(int amount) => NumberFormat('#,###').format(amount);
