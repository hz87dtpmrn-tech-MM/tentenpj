import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();

  static final AppDatabase instance = AppDatabase._();
  static const _dbName = 'tenten_app.db';
  static const _dbVersion = 1;

  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _open();
    return _database!;
  }

  Future<Database> _open() async {
    final dbPath = await getDatabasesPath();
    final path = p.join(dbPath, _dbName);

    return openDatabase(
      path,
      version: _dbVersion,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON;');
      },
      onCreate: (db, version) async {
        final batch = db.batch();

        batch.execute('''
          CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            name TEXT NOT NULL,
            monthly_income INTEGER NOT NULL DEFAULT 0 CHECK (monthly_income >= 0),
            currency TEXT NOT NULL DEFAULT 'KRW',
            is_profile_completed INTEGER NOT NULL DEFAULT 0 CHECK (is_profile_completed IN (0, 1)),
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now'))
          );
        ''');

        batch.execute('''
          CREATE TABLE categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            type TEXT NOT NULL CHECK (type IN ('income', 'expense')),
            icon TEXT,
            color_hex TEXT,
            is_default INTEGER NOT NULL DEFAULT 0 CHECK (is_default IN (0, 1)),
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now')),
            UNIQUE (user_id, type, name),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
          );
        ''');

        batch.execute('''
          CREATE TABLE fixed_expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            category_id INTEGER,
            title TEXT NOT NULL,
            amount INTEGER NOT NULL CHECK (amount >= 0),
            cycle TEXT NOT NULL DEFAULT 'monthly' CHECK (cycle IN ('monthly', 'yearly')),
            billing_day INTEGER CHECK (billing_day BETWEEN 1 AND 31),
            next_due_date TEXT,
            memo TEXT,
            is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
          );
        ''');

        batch.execute('''
          CREATE TABLE transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            category_id INTEGER,
            fixed_expense_id INTEGER,
            type TEXT NOT NULL CHECK (type IN ('income', 'expense')),
            amount INTEGER NOT NULL CHECK (amount >= 0),
            occurred_at TEXT NOT NULL,
            title TEXT NOT NULL,
            memo TEXT,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
            FOREIGN KEY (fixed_expense_id) REFERENCES fixed_expenses(id) ON DELETE SET NULL
          );
        ''');

        batch.execute('''
          CREATE TABLE budgets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            month TEXT NOT NULL,
            total_limit INTEGER NOT NULL CHECK (total_limit >= 0),
            note TEXT,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now')),
            UNIQUE (user_id, month),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
          );
        ''');

        batch.execute('''
          CREATE TABLE budget_categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            month TEXT NOT NULL,
            category_id INTEGER NOT NULL,
            limit_amount INTEGER NOT NULL CHECK (limit_amount >= 0),
            spent_amount INTEGER NOT NULL DEFAULT 0 CHECK (spent_amount >= 0),
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now')),
            UNIQUE (user_id, month, category_id),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
          );
        ''');

        batch.execute('''
          CREATE TABLE notification_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL UNIQUE,
            master_enabled INTEGER NOT NULL DEFAULT 1 CHECK (master_enabled IN (0, 1)),
            daily_summary_enabled INTEGER NOT NULL DEFAULT 1 CHECK (daily_summary_enabled IN (0, 1)),
            daily_summary_time TEXT DEFAULT '21:00',
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
          );
        ''');

        batch.execute('''
          CREATE TABLE notification_rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            fixed_expense_id INTEGER,
            title TEXT NOT NULL,
            is_enabled INTEGER NOT NULL DEFAULT 1 CHECK (is_enabled IN (0, 1)),
            remind_days_before INTEGER NOT NULL DEFAULT 1 CHECK (remind_days_before BETWEEN 0 AND 30),
            remind_at TEXT NOT NULL DEFAULT '09:00',
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            updated_at TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (fixed_expense_id) REFERENCES fixed_expenses(id) ON DELETE CASCADE
          );
        ''');

        batch.execute('CREATE INDEX idx_categories_user_type ON categories(user_id, type);');
        batch.execute('CREATE INDEX idx_fixed_expenses_user_active ON fixed_expenses(user_id, is_active);');
        batch.execute('CREATE INDEX idx_transactions_user_occurred ON transactions(user_id, occurred_at DESC);');
        batch.execute('CREATE INDEX idx_transactions_user_type_occurred ON transactions(user_id, type, occurred_at DESC);');
        batch.execute('CREATE INDEX idx_budgets_user_month ON budgets(user_id, month);');
        batch.execute('CREATE INDEX idx_budget_categories_user_month ON budget_categories(user_id, month);');
        batch.execute('CREATE INDEX idx_notification_rules_user_enabled ON notification_rules(user_id, is_enabled);');

        await batch.commit(noResult: true);
      },
    );
  }
}
